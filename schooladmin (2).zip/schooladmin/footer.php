<script src="adminerf/files/bower_components/jquery/js/jquery.min.js"></script>
<script src="adminerf/files/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script src="adminerf/files/bower_components/popper.js/js/popper.min.js"></script>
<script src="adminerf/files/bower_components/bootstrap/js/bootstrap.min.js"></script>
<script src="adminerf/files/assets/pages/widget/excanvas.js"></script>
<script src="adminerf/files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>
<script src="adminerf/files/bower_components/modernizr/js/modernizr.js"></script>
<script src="adminerf/files/assets/js/SmoothScroll.js"></script>
<script src="adminerf/files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="adminerf/files/bower_components/chart.js/js/Chart.js"></script>
<script src="adminerf/files/assets/pages/widget/amchart/amcharts.js"></script>
<script src="adminerf/files/assets/pages/widget/amchart/serial.js"></script>
<script src="adminerf/files/assets/pages/widget/amchart/light.js"></script>
<script src="adminerf/files/assets/js/pcoded.min.js"></script>
<script src="adminerf/files/assets/js/vertical/vertical-layout.min.js"></script>
<script src="adminerf/files/assets/pages/dashboard/custom-dashboard.js"></script>
<script src="adminerf/files/assets/js/script.js"></script>
<script src="http://mindmup.github.io/editable-table/mindmup-editabletable.js"></script>
<script src="adminerf/files/bower_components/switchery/js/switchery.min.js"></script>
<script src="adminerf/files/bower_components/bootstrap-tagsinput/js/bootstrap-tagsinput.js"></script>
<script src="cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.10.4/typeahead.bundle.min.js"></script>
<script src="adminerf/files/bower_components/bootstrap-maxlength/js/bootstrap-maxlength.js"></script>
<script src="adminerf/files/assets/pages/advance-elements/swithces.js"></script>
<script src="adminerf/files/assets/pages/jquery.filer/js/jquery.filer.min.js"></script>
<script src="adminerf/files/assets/pages/filer/custom-filer.js"></script>
<script src="adminerf/files/assets/pages/filer/jquery.fileuploads.init.js"></script>






<script src="adminerf/files/bower_components/modernizr/js/css-scrollbars.js"></script>
<script src="adminerf/files/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="adminerf/files/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/js/jszip.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/js/pdfmake.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/js/vfs_fonts.js"></script>
<script src="adminerf/files/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="adminerf/files/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="adminerf/files/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="adminerf/files/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="adminerf/files/bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/js/data-table-custom.js"></script>
<script src="adminerf/files/assets/pages/data-table/extensions/buttons/js/dataTables.buttons.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/extensions/buttons/js/buttons.flash.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/extensions/buttons/js/jszip.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/extensions/buttons/js/vfs_fonts.js"></script>
<script src="adminerf/files/assets/pages/data-table/extensions/buttons/js/buttons.colVis.min.js"></script>
<script src="adminerf/files/assets/pages/data-table/extensions/buttons/js/extension-btns-custom.js"></script>






