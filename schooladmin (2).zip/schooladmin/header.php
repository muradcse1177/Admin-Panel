	<title>Gradient Able bootstrap admin template by codedthemes </title>

	{{--For ALL--}}
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="description" content="Gradient Able Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
	<meta name="keywords" content="bootstrap, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
	<meta name="author" content="codedthemes" />
	<link rel="icon" href="http://html.codedthemes.com/gradient-able/files/assets/images/favicon.ico" type="image/x-icon">
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="adminerf/files/bower_components/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/icon/themify-icons/themify-icons.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/icon/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/css/jquery.mCustomScrollbar.css">
	<link rel="stylesheet" href="adminerf/files/assets/pages/chart/radial/css/radial.css" type="text/css" media="all">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/css/style.css">	
	<link rel="stylesheet" type="text/css" href="adminerf/files/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/pages/data-table/css/buttons.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/pages/data-table/extensions/buttons/css/buttons.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/icon/icofont/css/icofont.css">
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/css/component.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/assets/pages/menu-search/css/component.css">

	{{--Manage Academic--}}
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	<link rel="stylesheet" type="text/css" href="adminerf/files/bower_components/switchery/css/switchery.min.css">
	<link rel="stylesheet" type="text/css" href="adminerf/files/bower_components/bootstrap-tagsinput/css/bootstrap-tagsinput.css"/>

	{{--Teacher--}}
	<link rel="stylesheet" type="text/css" href="adminerf/files/bower_components/spectrum/css/spectrum.css" />
	<link rel="stylesheet" type="text/css" href="adminerf/files/bower_components/jquery-minicolors/css/jquery.minicolors.css" />
	<link href="adminerf/files/assets/pages/jquery.filer/css/jquery.filer.css" type="text/css" rel="stylesheet" />
	<link href="adminerf/files/assets/pages/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" type="text/css" rel="stylesheet" />



	<style>
		body::-webkit-scrollbar {
			width: 10px;
		 background-color: #F5F5F5;
		}

		body::-webkit-scrollbar-track {
			-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
		 background-color: #F5F5F5;
		}

		body::-webkit-scrollbar-thumb {
		  //background-color: darkgrey;
		  //outline: 1px solid slategrey;
		  background-color: #4099ff;

		 background-image: -webkit-gradient(linear, 0 0, 0 100%,
							color-stop(.5, rgba(255, 255, 255, .2)),
				color-stop(.5, transparent), to(transparent));
		}
</style>