<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from html.codedthemes.com/gradient-able/default/editable-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Dec 2017 06:43:43 GMT -->
   <head>
      <title>Gradient Able bootstrap admin template by codedthemes </title>
      <!--[if lt IE 10]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="description" content="Gradient Able Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
      <meta name="keywords" content="bootstrap, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
      <meta name="author" content="codedthemes" />
      <link rel="icon" href="http://html.codedthemes.com/gradient-able/files/assets/images/favicon.ico" type="image/x-icon">
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="files/bower_components/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="files/assets/icon/themify-icons/themify-icons.css">
      <link rel="stylesheet" type="text/css" href="files/assets/icon/icofont/css/icofont.css">
      <link rel="stylesheet" type="text/css" href="files/assets/icon/font-awesome/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="files/assets/css/style.css">
      <link rel="stylesheet" type="text/css" href="files/assets/css/jquery.mCustomScrollbar.css">
   </head>
   <body>
      <div class="theme-loader">
         <div class="loader-track">
            <div class="loader-bar"></div>
         </div>
      </div>
      <div id="pcoded" class="pcoded">
         <div class="pcoded-overlay-box"></div>
         <div class="pcoded-container navbar-wrapper">
            
                  <div class="pcoded-content">
                     <div class="pcoded-inner-content">
                        <div class="main-body">
                           <div class="page-wrapper">
                              <div class="page-header card">
                                 <div class="card-block">
                                    <h5 class="m-b-10">Editable Table</h5>
                                    <p class="text-muted m-b-10">lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
                                    <ul class="breadcrumb-title b-t-default p-t-10">
                                       <li class="breadcrumb-item">
                                          <a href="index-2.html"> <i class="fa fa-home"></i> </a>
                                       </li>
                                       <li class="breadcrumb-item"><a href="#!">Editable Table</a></li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="page-body">
                                 <div class="card">
                                    <div class="card-header">
                                       <h5>Edit With Click</h5>
                                       <span>Click on row to perform edit action then Enter for save</span>
                                    </div>
                                    <div class="card-block">
                                       <div class="table-responsive">
                                          <table class="table table-striped table-bordered" id="example-1">
                                            
                                          </table>
                                       </div>
                                     
                                    </div>
                                 </div>
                                 <div class="card">
                                    <div class="card-header">
                                       <h5>Edit With Button</h5>
                                       <span>Click on buttons to perform actions</span>
                                    </div>
                                    <div class="card-block">
                                       <div class="table-responsive">
                                          <table class="table table-striped table-bordered" id="example-2">
                                             <thead>
                                                <tr>
                                                   <th>#</th>
                                                   <th>First</th>
                                                   <th>First</th>
												 
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <th scope="row">1</th>
                                                   <td class="tabledit-view-mode"><span class="tabledit-span">Mark</span>
                                                      <input class="tabledit-input form-control input-sm" type="text" name="First" value="Mark">
                                                   </td>
												   <td class="tabledit-view-mode"><span class="tabledit-span">Mark</span>
                                                      <input class="tabledit-input form-control input-sm" type="text" name="First" value="Mark">
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <th scope="row">2</th>
                                                   <td class="tabledit-view-mode"><span class="tabledit-span">Jacob</span>
                                                      <input class="tabledit-input form-control input-sm" type="text" name="First" value="Jacob" disabled="">
                                                   </td>
                                                   <td class="tabledit-view-mode"><span class="tabledit-span">Thorntonkk</span>
                                                      <input class="tabledit-input form-control input-sm" type="text" name="Last" value="Thornton" disabled="">
                                                   </td>
                                                  
                                                </tr>
                                                <tr>
                                                   <th scope="row">3</th>
                                                   <td class="tabledit-view-mode"><span class="tabledit-span">Larry</span>
                                                      <input class="tabledit-input form-control input-sm" type="text" name="First" value="Larry" disabled="">
                                                   </td>
                                                   <td class="tabledit-view-mode"><span class="tabledit-span">the Bird</span>
                                                      <input class="tabledit-input form-control input-sm" type="text" name="Last" value="the Bird" disabled="">
                                                   </td>
                                                   
                                                </tr>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div id="styleSelector"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
	  
      <script src="files/bower_components/jquery/js/jquery.min.js"></script>
      <script src="files/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
      <script src="files/bower_components/popper.js/js/popper.min.js"></script>
      <script src="files/bower_components/bootstrap/js/bootstrap.min.js"></script>
      <script src="files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>
      <script src="files/bower_components/modernizr/js/modernizr.js"></script>
      <script src="files/bower_components/modernizr/js/css-scrollbars.js"></script>
      <script src="files/assets/pages/edit-table/jquery.tabledit.js"></script>
      <script src="files/assets/pages/edit-table/editable.js"></script>
      <script src="files/assets/js/pcoded.min.js"></script>
      <script src="files/assets/js/vertical/vertical-layout.min.js"></script>
      <script src="files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="files/assets/js/script.js"></script>

   </body>
   <!-- Mirrored from html.codedthemes.com/gradient-able/default/editable-table.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Dec 2017 06:43:44 GMT -->
</html>